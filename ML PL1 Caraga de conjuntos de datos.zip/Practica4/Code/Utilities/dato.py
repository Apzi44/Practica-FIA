from dataclasses import dataclass

@dataclass
class VectorDato:
    indice: int

    valor_cualitativo: str

    valores_cuantitativos: list