from dataclasses import dataclass
#Martinez Alor Zaddkiel de Jesus

@dataclass
class VectorDato:
    indice: int

    valor_cualitativo: str

    valores_cuantitativos: list