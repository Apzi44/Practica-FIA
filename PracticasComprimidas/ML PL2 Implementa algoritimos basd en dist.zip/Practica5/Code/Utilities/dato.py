from dataclasses import dataclass
#Martinez Alor Zaddkiel de Jesus

@dataclass
class VectorDato:
    indice: int
    valores: list

@dataclass
class VectorClasificar:
    indice: int
    valores: list
    funcion: list