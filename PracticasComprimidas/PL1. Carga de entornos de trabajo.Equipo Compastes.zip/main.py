from interfaz import Interfaz

Interfaz()